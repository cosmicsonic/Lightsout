import pygame, random

pygame.init()
screen = pygame.display.set_mode((500, 500))
done = False

pygame.display.set_caption("Lights Out! by Theo")

board = [
  [0,0,0,0,0],
  [0,0,0,0,0],
  [0,0,0,0,0],
  [0,0,0,0,0],
  [0,0,0,0,0]
]
tile_size = 100


def drawGrid(board):
  color = (255,0,0)
  for i in range(1, len(board)):
    pygame.draw.line(screen, color, (0, i*tile_size), (500, i*tile_size))

    pygame.draw.line(screen, color, (i*tile_size, 0), (i*tile_size, 500))

def drawBoard(board):
  yellow = (200,200,0)
  black = (0,0,0)
  colors = [black, yellow]
  for i in range(len(board)):
    for k in range(len(board[i])):
      rect = pygame.Rect(k*tile_size, i*tile_size, tile_size, tile_size)
      value = board[i][k]
      pygame.draw.rect(screen, colors[value], rect)

  drawGrid(board)

def toggle(board, x, y):
  value = board[y][x]
  board[y][x] = [1, 0][value]

def changeLights(board,x,y):
  toggle(board, x, y)

  if y > 0:
    toggle(board,x,y-1)

  if y < len(board)-1:
    toggle(board,x,y+1)

  if x > 0:
    toggle(board,x-1,y)

  if x < len(board)-1:
    toggle(board,x+1,y)

def getMouse(board):
    x, y = pygame.mouse.get_pos()
    x = (x // tile_size) % len(board)
    y = (y // tile_size) % len(board)

    changeLights(board, x, y)

def setUpGame(board):
    for i in range(10):
        x = random.randint(0, 4)
        y = random.randint(0, 4)
        changeLights(board, x, y)

def clear(board):
    for y in range(len(board)):
        for x in range(len(board)):
            board[y][x] = 0

setUpGame(board)
drawBoard(board)
clicked = False

while not done:
  for event in pygame.event.get():
    if event.type == pygame.QUIT:
      done = True
    if event.type == pygame.KEYDOWN:
        if event.key == pygame.K_r:
            clear(board)
            setUpGame(board)
            drawBoard(board)

    if pygame.mouse.get_pressed()[0] and clicked == False:
        clicked = True
        getMouse(board)
        drawBoard(board)
    elif pygame.mouse.get_pressed()[0] == False:
        clicked = False

  pygame.display.flip()